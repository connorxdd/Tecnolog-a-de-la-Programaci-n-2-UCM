package simulator.factories;

import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import simulator.misc.Vector;
import simulator.model.Body;

public class BasicBodyBuilder extends Builder<Body>{
	
	public BasicBodyBuilder() {
		
	}
	
	public Body createInstance(JSONObject info) {
		Body result = null;
		Vector auxPos = null;
		Vector auxVel = null;
		if(info.getString("type").equals("basic")) {
			try {
				JSONObject jo2 = info.getJSONObject("data");
				auxPos = new Vector(tratarJOArray(jo2.getJSONArray("pos")));
				auxVel = new Vector(tratarJOArray(jo2.getJSONArray("vel")));
				//Queda por comprobar como hacer la aceleracion
				result = new Body(jo2.getString("id"), jo2.getDouble("mass"), auxPos, auxVel, auxPos.scale(0)); 
			}catch(IllegalArgumentException e) {
				System.out.println(e);
			}
		}
		return result;
	}
	
	public double[] tratarJOArray(JSONArray arrayFloat) {		
		double[] result = new double[arrayFloat.length()];
		
		for(int i = 0; i < arrayFloat.length(); i++) {
			result[i] = Double.parseDouble(arrayFloat.getString(i)) ;
		}
		return result;		
	}

	@Override
	public List<JSONObject> getInfo() {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	
}
