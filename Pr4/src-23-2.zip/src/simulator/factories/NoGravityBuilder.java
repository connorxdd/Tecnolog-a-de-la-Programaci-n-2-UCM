package simulator.factories;

import java.util.List;

import org.json.JSONObject;

import simulator.model.GravityLaws;
import simulator.model.NewtonUniversalGravitation;
import simulator.model.NoGravity;

public class NoGravityBuilder extends Builder<GravityLaws>{

	public NoGravity createNG() {
		return new NoGravity();
	}

	@Override
	public GravityLaws createInstance(JSONObject info) {
		
		NoGravity result = null;
		if(info.get("type").equals("ftcg")){
			result = new NoGravity();
		}
		return result;
	}

	@Override
	public List<JSONObject> getInfo() {
		// TODO Auto-generated method stub
		return null;
	}
}
