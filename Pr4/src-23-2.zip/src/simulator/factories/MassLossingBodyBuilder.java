package simulator.factories;

import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import simulator.misc.Vector;
import simulator.model.*;

public class MassLossingBodyBuilder extends Builder<Body>{
	
	public MassLossingBodyBuilder() {
		
	}
	public MassLossingBody createInstance(JSONObject info){
		MassLossingBody result = null;
		
		if(info.get("type").equals("mlb")){
			try {
				JSONObject jo2 = info.getJSONObject("data");
				Vector auxPos = new Vector(tratarJOArray(jo2.getJSONArray("pos")));
				Vector auxVel = new Vector(tratarJOArray(jo2.getJSONArray("vel")));;
				//Revisar para hacer la aceleracion.
				result = new MassLossingBody(jo2.getString("id"), jo2.getDouble("mass"), auxPos, auxVel, 
						auxPos.scale(0), jo2.getDouble("factor"), jo2.getDouble("freq"), 0.0);
			}
			catch(IllegalArgumentException e) {
				System.out.println(e);
			}
		}
		return result;
	}

	public double[] tratarJOArray(JSONArray arrayFloat) {		
		double[] result = new double[arrayFloat.length()];
		
		for(int i = 0; i < arrayFloat.length(); i++) {
			result[i] = Double.parseDouble(arrayFloat.getString(i)) ;
		}
		return result;		
	}
	
	public List<JSONObject> getInfo(){
		return null;
	}

}
