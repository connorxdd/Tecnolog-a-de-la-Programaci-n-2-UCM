package simulator.factories;

import java.util.List;

import org.json.JSONObject;

import simulator.model.*;

public class FallingToCenterGravityBuilder extends Builder<GravityLaws>{

	public FallingToCenterGravity createFCG() {
		return new FallingToCenterGravity();
	}
	
	public GravityLaws createInstance(JSONObject info){
		GravityLaws result = null;
		if(info.get("type").equals("ftcg")){
			result = new FallingToCenterGravity();
		}
		return result;
	}

	@Override
	public List<JSONObject> getInfo() {
		// TODO Auto-generated method stub
		return null;
	}
	
}
