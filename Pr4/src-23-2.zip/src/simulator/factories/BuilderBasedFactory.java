package simulator.factories;

import java.util.List;

import org.json.JSONObject;

public class BuilderBasedFactory<T> implements Factory<T>{
	private List<Builder<T>> lista;
	
	public BuilderBasedFactory(List<Builder<T>> builders) {
		this.lista= builders;
	}
	
	@Override
	public T createInstance(JSONObject info) {
		T result=null;
		for (Builder<T> builder : lista) {
			result = builder.createInstance(info);
			if (result!=null) {break;}
		}
		return result;
	}

	@Override
	public List<JSONObject> getInfo() {
		// TODO Auto-generated method stub
		return null;
	}

}
