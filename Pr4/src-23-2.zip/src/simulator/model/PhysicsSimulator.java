package simulator.model;

import java.util.List;

public class PhysicsSimulator {
	private double tiempoReal;
	private double tiempoActual;
	private GravityLaws leyes;
	private List<Body> lista;
	
	public PhysicsSimulator(double tiempoReal, GravityLaws leyes) {
		this.tiempoReal = tiempoReal;
		this.leyes = leyes;
		this.tiempoActual = 0.0;
	}
	
	public void advance() {
		leyes.apply(this.lista);
		for(Body i: this.lista) {
			i.move(tiempoReal);
		}
		this.tiempoActual += this.tiempoReal;
	}
	
	public void addBody(Body b) {
		for(Body i: this.lista) {
			if(i.id.equals(b.id)) {
				throw new IllegalArgumentException("ID�s iguales");
			}
		}
		lista.add(b);
	}
	
	public String toString() {
		return "{ \"time\": " + this.tiempoActual + ", \"bodies\": " + this.lista.toString() + " }";
	}
}
