package simulator.model;

import java.util.List;

import simulator.misc.Vector;


public class NewtonUniversalGravitation implements GravityLaws{
	private final double G = 6.67*Math.pow(10, -11);
	@Override
	public void apply(List<Body> bodies) {
		// TODO Auto-generated method stub

		for(int i = 0; i <bodies.size();i++){
			Vector fuerza = new Vector(bodies.get(0).pos.dim());
			for(int j = 0; j <bodies.size();i++){
				if(j!=i){
					for (int index = 0; index < bodies.get(j).getPosition().dim(); index++) {
						Vector diff = new Vector(bodies.get(0).pos.dim());
						diff=bodies.get(j).pos.minus(bodies.get(i).pos);
						double value = G*bodies.get(i).getMass()*bodies.get(j).getMass()/
								(Math.pow(Math.abs(diff.magnitude()),2));
						diff.direction().scale(value);
					}
					bodies.get(i).setAcceleration(fuerza.scale(1/bodies.get(i).getMass()));
				}
			}
		}
	}
							
}
