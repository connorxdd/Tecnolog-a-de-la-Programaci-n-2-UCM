package simulator.control;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;

import org.json.JSONObject;
import org.json.JSONTokener;

import simulator.factories.Builder;
import simulator.factories.BuilderBasedFactory;
import simulator.factories.Factory;
import simulator.model.Body;
import simulator.model.PhysicsSimulator;

public class Controller {
	private PhysicsSimulator fisicas;
	private Factory<Body> factoria;
	
	public Controller(PhysicsSimulator fisicas) {
		this.fisicas = fisicas;
		this.factoria = new BuilderBasedFactory(null);
	}
	
	public void loadBodies(InputStream in) {
		JSONObject jsonInupt = new JSONObject(new JSONTokener(in));
		this.factoria.createInstance(jsonInupt);
	}
	
	public void run(int n, OutputStream out) throws IOException {
		String resultado = "{ \"states\":";
		resultado += this.fisicas.toString();
		for(int i = 0; i < n; i++) {
			this.fisicas.advance();
			resultado += this.fisicas.toString();
		}
		out.write(resultado.getBytes());
	}
}
